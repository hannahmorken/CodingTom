module Main where


main :: IO ()
main = putStrLn "Hello, Haskell!"
